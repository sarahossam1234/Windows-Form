﻿using System;

namespace ConsoleApp10
{
    class Program
    {
        static void Main(string[] args)
        {
            var smtpSender = new SMTPSender(); // This should now recognize SMTPSender
            // Use smtpSender to send emails or get configurations
        }
    }
}
